import SummaryCards from "../SummaryCards";

export default function SummaryCardsExample() {
  return <SummaryCards balance={1500.50} gains={2000.00} losses={500.00} />;
}
